<?php

$hostname = "sql1.njit.edu"   ;
$username = "ap725" ;
$project  = "ap725"   ;
$password = "goober83" ;

?>